# T-academy
<Python을 활용한 데이터분석 기초>

T academy Talk ON Seminar on Data Analysis and Visualization

Lecturer: Taewan Yoon

Online Lecture URL:
https://tacademy.skplanet.com/live/player/onlineLectureDetail.action?seq=132#sec3
